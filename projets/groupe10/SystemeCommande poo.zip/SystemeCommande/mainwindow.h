#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <vector>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

// Enumération pour les catégories d'articles
enum class Categorie { Repas, Electronique, HabitsFille, HabitsGarcon };

// Structure représentant un article
struct Article {
    QString nom;
    double prix;
    Categorie categorie;
};

// Structure représentant une commande
struct Commande {
    std::vector<Article> articles; // Liste des articles commandés
    QString modeLivraison;          // Mode de livraison choisi
    QString moyenPaiement;          // Moyen de paiement choisi
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_btnAfficherCategorie_clicked(); // Affiche les articles d'une catégorie
    void on_btnAjouterArticle_clicked();    // Ajoute un article au panier
    void on_btnTerminerCommande_clicked();  // Termine et sauvegarde la commande
    void on_btnAfficherHistorique_clicked(); // Affiche l'historique des commandes
    void on_comboModeLivraison_currentIndexChanged(int index); // Change mode livraison
    void on_comboMoyenPaiement_currentIndexChanged(int index); // Change moyen paiement

private:
    Ui::MainWindow *ui;

    std::vector<Article> menu;    // Tous les articles disponibles
    Commande commandeEnCours;     // La commande en cours

    void initialiserMenu();       // Remplit la liste des articles
    void afficherArticlesCategorie(Categorie cat); // Affiche les articles dans la liste
    void sauvegarderCommande(const Commande& cmd); // Sauvegarde la commande dans fichier
    void afficherHistorique();    // Affiche l'historique des commandes
    QString categorieToString(Categorie cat); // Convertit l'enum en QString
};

#endif // MAINWINDOW_H

