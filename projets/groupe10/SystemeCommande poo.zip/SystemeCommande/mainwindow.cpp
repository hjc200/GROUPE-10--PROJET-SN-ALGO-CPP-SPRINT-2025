#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    initialiserMenu();

    // Remplir combo pour les catégories
    ui->comboCategorie->addItem("Repas");
    ui->comboCategorie->addItem("Electronique");
    ui->comboCategorie->addItem("Habits Filles");
    ui->comboCategorie->addItem("Habits Garçons");

    // Remplir combo pour le mode de livraison
    ui->comboModeLivraison->addItem("Standard (1-2 heures)");
    ui->comboModeLivraison->addItem("Rapide (30 min)");

    // Remplir combo pour moyen paiement
    ui->comboMoyenPaiement->addItem("Carte bancaire");
    ui->comboMoyenPaiement->addItem("Paypal");
    ui->comboMoyenPaiement->addItem("Espèces");

    // Initialisation mode livraison et paiement
    commandeEnCours.modeLivraison = "Standard (1-2 heures)";
    commandeEnCours.moyenPaiement = "Carte bancaire";
}

MainWindow::~MainWindow()
{
    delete ui;
}

// Remplit la liste "menu" avec les articles
void MainWindow::initialiserMenu()
{
    menu = {
        // Repas
        {"Pizza au fromage", 3000, Categorie::Repas},
        {"Burger Maison", 2500, Categorie::Repas},
        {"Poisson braise", 2000, Categorie::Repas},
        {"Poulet DG", 1500, Categorie::Repas},
        {"Riz au poulet", 2700, Categorie::Repas},
        {"Eru", 1000, Categorie::Repas},

        // Electronique
        {"Casque Bluetooth", 12000, Categorie::Electronique},
        {"Souris sans fil", 4000, Categorie::Electronique},
        {"Clavier RGB", 10000, Categorie::Electronique},
        {"Batterie externe", 8500, Categorie::Electronique},
        {"Iphone XR", 100000, Categorie::Electronique},

        // Habits filles
        {"Robe rose", 6000, Categorie::HabitsFille},
        {"Jupe plisee", 4500, Categorie::HabitsFille},
        {"Sandales", 3000, Categorie::HabitsFille},

        // Habits garcons
        {"T-shirt LV", 3500, Categorie::HabitsGarcon},
        {"Short sport", 4000, Categorie::HabitsGarcon},
        {"Casquette", 2500, Categorie::HabitsGarcon},
        {"Survetement Barcelone", 20000, Categorie::HabitsGarcon}
    };
}

// Convertit enum en texte affichable
QString MainWindow::categorieToString(Categorie cat)
{
    switch(cat) {
    case Categorie::Repas: return "Repas";
    case Categorie::Electronique: return "Electronique";
    case Categorie::HabitsFille: return "Habits Filles";
    case Categorie::HabitsGarcon: return "Habits Garçons";
    }
    return "";
}

// Affiche les articles d'une catégorie dans la liste
void MainWindow::afficherArticlesCategorie(Categorie cat)
{
    ui->listArticles->clear();
    for (const Article& a : menu) {
        if (a.categorie == cat) {
            ui->listArticles->addItem(a.nom + " - " + QString::number(a.prix) + " francs");
        }
    }
}

// Slot appelé quand on clique sur "Afficher catégorie"
void MainWindow::on_btnAfficherCategorie_clicked()
{
    int index = ui->comboCategorie->currentIndex();
    Categorie cat = static_cast<Categorie>(index);
    afficherArticlesCategorie(cat);
}

// Slot appelé quand on clique sur "Ajouter article"
void MainWindow::on_btnAjouterArticle_clicked()
{
    int indexArticle = ui->listArticles->currentRow();
    if (indexArticle < 0) {
        QMessageBox::warning(this, "Attention", "Veuillez sélectionner un article à ajouter.");
        return;
    }

    // Trouver la catégorie sélectionnée
    int catIndex = ui->comboCategorie->currentIndex();
    Categorie cat = static_cast<Categorie>(catIndex);

    // Trouver l'article correspondant dans menu (même catégorie, même index dans affichage)
    int count = -1;
    for (const Article& a : menu) {
        if (a.categorie == cat) {
            ++count;
            if (count == indexArticle) {
                commandeEnCours.articles.push_back(a);
                QMessageBox::information(this, "Ajouté", a.nom + " ajouté au panier.");
                break;
            }
        }
    }

    // Afficher panier actuel dans la liste "listPanier"
    ui->listPanier->clear();
    double total = 0;
    for (const Article& a : commandeEnCours.articles) {
        ui->listPanier->addItem(a.nom + " - " + QString::number(a.prix) + " francs");
        total += a.prix;
    }
    ui->labelTotal->setText("Total: " + QString::number(total) + " francs");
}

// Sauvegarde la commande dans un fichier texte simple
void MainWindow::sauvegarderCommande(const Commande& cmd)
{
    QFile file("commandes.txt");
    if (!file.open(QIODevice::Append | QIODevice::Text)) {
        QMessageBox::warning(this, "Erreur", "Impossible d'ouvrir le fichier de sauvegarde.");
        return;
    }

    QTextStream out(&file);
    out << "Nouvelle commande\n";
    for (const Article& a : cmd.articles) {
        out << "- " << a.nom << " : " << a.prix << " francs\n";
    }
    out << "Mode de livraison : " << cmd.modeLivraison << "\n";
    out << "Moyen de paiement : " << cmd.moyenPaiement << "\n";
    double total = 0;
    for (const Article& a : cmd.articles) total += a.prix;
    out << "Total : " << total << " francs\n";
    out << "---------------------------\n";

    file.close();
}

// Slot appelé quand on clique sur "Terminer commande"
void MainWindow::on_btnTerminerCommande_clicked()
{
    if (commandeEnCours.articles.empty()) {
        QMessageBox::warning(this, "Attention", "Le panier est vide.");
        return;
    }
    sauvegarderCommande(commandeEnCours);
    QMessageBox::information(this, "Commande", "Commande sauvegardée avec succès !");
    // Vider la commande en cours
    commandeEnCours.articles.clear();
    ui->listPanier->clear();
    ui->labelTotal->setText("Total: 0 francs");
}

// Slot appelé quand on clique sur "Afficher historique"
void MainWindow::afficherHistorique()
{
    QFile file("commandes.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Erreur", "Impossible d'ouvrir le fichier historique.");
        return;
    }

    QString contenu = file.readAll();
    file.close();

    // Affiche l'historique dans une fenêtre message
    QMessageBox::information(this, "Historique des commandes", contenu);
}

void MainWindow::on_btnAfficherHistorique_clicked()
{
    afficherHistorique();
}

// Slots pour changer mode livraison et moyen paiement
void MainWindow::on_comboModeLivraison_currentIndexChanged(int index)
{
    commandeEnCours.modeLivraison = ui->comboModeLivraison->currentText();
}

void MainWindow::on_comboMoyenPaiement_currentIndexChanged(int index)
{
    commandeEnCours.moyenPaiement = ui->comboMoyenPaiement->currentText();
}
